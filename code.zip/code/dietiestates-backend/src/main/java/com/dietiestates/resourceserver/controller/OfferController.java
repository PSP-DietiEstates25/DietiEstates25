package com.dietiestates.resourceserver.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dietiestates.resourceserver.dto.request.OfferRequest;
import com.dietiestates.resourceserver.dto.response.OfferResponse;
import com.dietiestates.resourceserver.service.OfferService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/realestates/{realestateid}/offers")
@RequiredArgsConstructor
@Validated
public class OfferController {

	private final OfferService offerService;
	
	@PostMapping
	public ResponseEntity<OfferResponse> createOffer(
			@RequestBody OfferRequest request,
			@PathVariable Long realestateid
		){
		var offer = offerService.createOffer(request, realestateid);
		return ResponseEntity.status(HttpStatus.CREATED).body(offer);
	}
	/*
    private final OfferService offerService;

    @PostMapping
    @PreAuthorize("hasAuthority('CLIENT') and !hasAnyAuthority('AGENT','ADMIN')")
    public ResponseEntity<Offer> propose(
            @PathVariable Long realestateId,
            @Valid @RequestBody OfferProposalRequest payload,
            Authentication authentication) {

        String email = authentication.getName();
        Offer offer = offerService.propose(email, realestateId, payload);

        // in uscita ritorna direttamente l'ENTITY, con ResponseEntity parametrici
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(offer);
    }

    @GetMapping
    @PreAuthorize("hasAnyAuthority('AGENT','ADMIN')")
    public ResponseEntity<List<Offer>> listForEstate(
            @PathVariable Long adId,
            @RequestParam(required = false, defaultValue = "0") Integer page,
            @RequestParam(required = false, defaultValue = "12") Integer size,
            Authentication authentication) {

        String email = authentication.getName();
        List<Offer> offers = offerService.listForEstate(email, adId, page, size);
        return ResponseEntity.ok(offers);
    }
    */
}
