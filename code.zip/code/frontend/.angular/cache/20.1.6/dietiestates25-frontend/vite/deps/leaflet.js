import {
  require_leaflet_src
} from "./chunk-NQJSDSPG.js";
import "./chunk-3OV72XIM.js";
export default require_leaflet_src();
