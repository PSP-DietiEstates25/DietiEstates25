//create your environment.development.ts
export const environment = {
    production: false,
    apiBaseUrl: 'http://localhost:8080',
    apiKeyParam: "apiKey=",
    geoapifyAPIKey: "d6ef1142975941368b3831ce8487681b",

    manualIssuer: "http://localhost:8080",
    manualRedirectUri: window.location.origin + '/',
    manualClientId: "DietiEstates25",
    manualResponseType: "code",
    manualScope: "openid profile",
    manualRequireHttps: false,

    googleIssuer: "googleIssuer",
    googleRedirectUri: "googleRedirectUri",
    googleClientId: "googleClientId",
    googleResponseType: "googleResponseType",
    googleScope: "googleScope",
    googleRequireHttps: false,

    githubIssuer: "githubIssuer",
    githubRedirectUri: "githubRedirectUri",
    githubClientId: "githubClientId",
    githubResponseType: "githubResponseType",
    githubScope: "githubScope",
    githubRequireHttps: false,

    facebookIssuer: "facebookIssuer",
    facebookRedirectUri: "facebookRedirectUri",
    facebookClientId: "facebookClientId",
    facebookResponseType: "facebookResponseType",
    facebookScope: "facebookScope",
    facebookRequireHttps: false
};
