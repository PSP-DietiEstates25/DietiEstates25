import { Component, effect, inject, OnInit } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../vecchioService/auth/auth.service';
import { MenuToggleComponent } from '../../buttons/menu_toggle/menu-toggle.component';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface NavLink {
  label: string;
  path: string;
}

@Component({
  selector: 'app-navbar',
  standalone: true,
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
  imports: [CommonModule, RouterLink, RouterLinkActive, MenuToggleComponent],
})
export class NavbarComponent implements OnInit {

  private httpClient = inject(HttpClient);

  isMenuOpen = false;
  isAuthenticated = false;
  role: 'ADMIN' | 'AGENT' | 'CLIENT' | null = null;
  email = '';

  // link base
  navLinks: NavLink[] = [
    { label: 'Home', path: '/' },
    { label: 'Ricerca', path: '/search' },
    { label: 'Mappa', path: '/map' },
  ];

  private auth = inject(AuthService);
  private router = inject(Router);

  constructor() {
    effect(() => {
      const state = this.auth.authState();
      this.isAuthenticated = !!state.isAuthenticated;
      const email = state.email;
    });
    effect(() => {
      try {
        this.role = this.auth.role ? this.auth.role() : null;
      } catch {
        this.role = null;
      }
    });
  }

    ngOnInit(): void {
    this.getUserInfo();
  }

  toggleMenu() {
    this.isMenuOpen = !this.isMenuOpen;
  }
  
  closeMenu() {
    this.isMenuOpen = false;
  }

  onClickLogin(){
    this.closeMenu();
    // The Backend is configured to trigger login when unauthenticated
    window.location.href = environment.apiBaseUrl;
  }

  onClickRegister(){}

  /* VECCHIO LOGOUT
  logout() {
    this.auth.logout();
    this.closeMenu();
    clearStorage();
    this.router.navigateByUrl('/auth');
  }
  */

  logout(): void {
    this.closeMenu();
    this.httpClient.post('/logout', null)
      /*
      .pipe(catchError((error) => {
        console.error(error);
        return of(null);
      }))
      */
      .subscribe(() => {
        this.isAuthenticated = false;
        this.email = '';
      });
  }

  getUserInfo(): void {
    this.httpClient.get<any>('/userinfo')
      /*
      .pipe(catchError((error) => {
        console.error(error);
        return of(null);
      }))
      */
      .subscribe((userInfo) => {
        if (userInfo) {
          this.isAuthenticated = true;
          this.email = userInfo.sub;
        }
      });
  }

  /*
  authorizeMessages(): void {
    // Trigger the Backend to perform the authorization_code grant flow.
    // After authorization is complete, the Backend will redirect back to this app.
    window.location.href = environment.apiBaseUrl + "/oauth2/authorization/messaging-client-authorization-code";
  }
  */
}

function clearStorage() {
  localStorage.removeItem('userEmail');
  localStorage.removeItem('userRole');
  localStorage.removeItem('isAuthenticated');
}
