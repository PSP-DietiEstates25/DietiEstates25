package com.dietiestates.authorization.mapper;

import com.dietiestates.authorization.dto.request.RegisterRequest;
import com.dietiestates.authorization.dto.response.AccountResponse;
import com.dietiestates.authorization.model.Account;
import com.dietiestates.authorization.spec.AccountSpec;

public interface AccountMapper {

	AccountSpec toSpec(RegisterRequest request);
	
	AccountResponse fromEntity(Account account);
}