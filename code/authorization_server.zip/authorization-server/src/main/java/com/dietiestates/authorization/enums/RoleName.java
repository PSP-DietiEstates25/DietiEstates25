package com.dietiestates.authorization.enums;

public enum RoleName {

	ADMIN,
	USER,
	ESTATE_AGENT
}
