package com.dietiestates.resource_server.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class SearchRequest {

    @NotEmpty(message = "Category is mandatory")
    @NotBlank(message = "Category is mandatory")
    private String category;

    @Positive(message = "Cadastral filter id must be a positive number")
    private Long cadastralFilterId;

    @Positive(message = "Detail id must be a positive number")
    private Long detailId;

}
