package com.dietiestates.resource_server.mapperdefaultimpl;

import com.dietiestates.resource_server.dto.request.NotificationRequest;
import com.dietiestates.resource_server.dto.response.NotificationResponse;
import com.dietiestates.resource_server.mapper.NotificationMapper;
import com.dietiestates.resource_server.model.Notification;
import com.dietiestates.resource_server.spec.NotificationSpec;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
public class NotificationMapperDefaultImpl implements NotificationMapper {
	
	@Override
	public NotificationSpec toSpec(NotificationRequest request) {
		return NotificationSpec.builder()
				.message(request.getMessage())
                .notificationCategory(request.getNotificationCategory())
                .isVisible(request.getIsVisible())
                .negotiationId(request.getNegotiationId())
				.build();
	}
	
	@Override
	public NotificationResponse fromEntity(Notification notification) {
		return NotificationResponse.builder()
				.id(notification.getId())
				.createdDate(notification.getCreatedDate())
				.lastModifiedDate(notification.getLastModifiedDate())
				.message(notification.getMessage())
                .notificationCategory(notification.getNotificationCategory().toString())
                .isVisible(notification.getIsVisible())
                .realEstateId(notification.getNegotiation().getRealEstate().getId())
				.build();
	}

    @Override
    public List<NotificationResponse> createNotificationsResponse(List<Notification> notifications){
        var notificationsResponse = new ArrayList<NotificationResponse>();
        notifications.forEach((notification) -> {
            notificationsResponse.add(this.fromEntity(notification));
        });

        return notificationsResponse;
    }

    @Override
    public Page<NotificationResponse> createPagedNotificationsResponse(Page<Notification> notifications){
        return notifications.map(this::fromEntity);
    }
}
