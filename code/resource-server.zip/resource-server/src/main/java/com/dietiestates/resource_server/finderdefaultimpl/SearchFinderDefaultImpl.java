package com.dietiestates.resource_server.finderdefaultimpl;

import com.dietiestates.resource_server.exception.notfound.SearchNotFoundException;
import com.dietiestates.resource_server.finder.SearchFinder;
import com.dietiestates.resource_server.model.Search;
import com.dietiestates.resource_server.repository.SearchRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
public class SearchFinderDefaultImpl implements SearchFinder {

	private final SearchRepository searchRepository;

	@Override
	public Search getSearchById(Long id)
			throws SearchNotFoundException {
		return searchRepository.findById(id)
				.orElseThrow(SearchNotFoundException::new);
	}

    @Override
    public List<Search> getAllSearches() {

        var searchesIterable = searchRepository.findAll();
        var allSearches = new ArrayList<Search>();
        searchesIterable.forEach(allSearches::add);

        return allSearches;
    }

    @Override
    public Page<Search> getUserSearches(Long userId, Pageable pageable) {
        return searchRepository.findByUserId(userId, pageable);
    }
}
