//create your environment.development.ts
export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:8080',
  apiKeyParam: 'apiKey=',
  geoapifyAPIKey: 'd6ef1142975941368b3831ce8487681b',
  loginUrl: `http://localhost:8080/oauth2/authorization/messaging-client-oidc?prompt=login`,
  placesRadius: 500,
  placesLimit: 20,
  searchFooterMaxVisiblePages: 5,
  offerFooterMaxVisiblePages: 5,
};
