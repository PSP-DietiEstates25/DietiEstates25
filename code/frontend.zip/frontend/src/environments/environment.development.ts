const apiBaseUrl = 'http://localhost:8080';

export const environment = {
    production: false,
    apiBaseUrl,
    apiKeyParam: "apiKey=",
    geoapifyAPIKey: "d6ef1142975941368b3831ce8487681b",
    loginUrl: `${apiBaseUrl}/oauth2/authorization/messaging-client-oidc?prompt=login`
};