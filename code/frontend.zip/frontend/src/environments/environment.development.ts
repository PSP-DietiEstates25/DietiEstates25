//create your environment.development.ts
export const environment = {
    production: false,
    apiBaseUrl: 'http://localhost:8080',
    apiKeyParam: "apiKey=",
    geoapifyAPIKey: "d6ef1142975941368b3831ce8487681b"
};