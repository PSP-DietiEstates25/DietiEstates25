//create your environment.development.ts
const apiBaseUrl = 'http://localhost:8080';

export const environment = {
    production: true,
    apiBaseUrl,
    apiKeyParam: "apiKey=",
    geoapifyAPIKey: "secretKey",
    loginUrl: `${apiBaseUrl}/oauth2/authorization/messaging-client-oidc?prompt=login`,
};