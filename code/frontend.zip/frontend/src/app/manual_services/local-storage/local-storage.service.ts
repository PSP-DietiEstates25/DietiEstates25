import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LocalStorageService {
  
  setItem(key: string, value: string){
    localStorage.setItem(key, value);
  }

  getItem(key: string): string | null {
    return localStorage.getItem(key);
  }

  removeItem(key: string){
    localStorage.removeItem(key);
  }

  clear(){
    localStorage.removeItem("isAuthenticated");
    localStorage.removeItem("role");
  }
}
