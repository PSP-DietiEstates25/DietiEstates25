import { Component, EventEmitter, Input, Output, inject } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { VisitControllerService } from '../../services/services';
import { firstValueFrom } from 'rxjs';
@Component({
  selector: 'app-visit-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './visit-form.component.html',
})
export class VisitFormComponent {

  private formBuilder = inject(FormBuilder);
  private visitService = inject(VisitControllerService);

  @Input()
  realEstateId!: number;

  @Input()
  isLoggedIn = false;

  @Output()
  success = new EventEmitter<void>();

  @Output()
  loginRequired = new EventEmitter<void>();

  loading = false;
  successMessage = '';
  errorMessage = '';
  today = new Date().toISOString().slice(0, 10);

  form = this.formBuilder.group({
    date: [null, [Validators.required]],
    time: [null, [Validators.required]],
  });

  async submitVisit() {
    this.successMessage = '';
    this.errorMessage = '';

    if (!this.isLoggedIn) {
      this.loginRequired.emit();
      return;
    }
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.loading = true;
    try {
      const body = {
        category: 'VISIT',
        status: 'PENDING',
        date: this.form.value.date!, // "YYYY-MM-DD"
        time: this.form.value.time!, // "HH:mm"
      };

      await firstValueFrom(
        this.visitService.createVisit({ realestateid: this.realEstateId, body })
      );

      this.successMessage = 'Richiesta inviata!';
      this.success.emit();
      this.form.reset();
    } catch (error: any) {
      this.errorMessage = error?.error?.message ?? 'Errore durante la richiesta di visita.';
    } finally {
      this.loading = false;
    }
  }
}
