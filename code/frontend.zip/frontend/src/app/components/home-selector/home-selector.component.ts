import { Component, inject } from '@angular/core';
import { LocalStorageService } from '../../services/services/local-storage.service';
import { HomeComponent } from '../home/home.component';
import { AgentDashboardComponent } from '../agent-dashboard/agent-dashboard.component';
import { AdminDashboardComponent } from '../admin-dashboard/admin-dashboard.component';
import { Router } from '@angular/router';
import { windowTime } from 'rxjs';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-home-selector',
  imports: [HomeComponent, AgentDashboardComponent, AdminDashboardComponent],
  templateUrl: './home-selector.component.html',
  styleUrl: './home-selector.component.scss'
})
export class HomeSelectorComponent {

  private readonly localStorageService = inject(LocalStorageService);
  private readonly routerService = inject(Router);

  role!: string;

  constructor(){
    const role = this.localStorageService.getItem("role");
    this.checkRoleValidity(role);
  }

  checkRoleValidity(role: string | null){
    console.log("eseguito")
    if(role === null)
      window.location.href = environment.loginUrl;
  }
}
