import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NotificationsFacade } from '../notifications/notifications.facade';
import { NotificationCategory } from '../../enums/notification-category.enum';
import { NotificationPaginatorService } from '../../manual_services/notification_paginator/notification-paginator.service';

@Component({
  selector: 'app-notifications-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './notifications-list.component.html',
  styleUrl: './notifications-list.component.scss',
})
export class NotificationsListComponent implements OnInit {
  readonly facade = inject(NotificationsFacade);
  notificationPaginatorService = inject(NotificationPaginatorService);
  notifications = this.facade.notifications;
  private sessionEntryTime = 0;

  ngOnInit(): void {
    const lastSeenIso = this.facade.lastSeen();
    console.log('[List] Init LastSeen:', lastSeenIso);
    
    // 1. Catturiamo il tempo di ULTIMA VISITA REGISTRATA
    this.sessionEntryTime = lastSeenIso ? new Date(lastSeenIso).getTime() : 0;

    // 2. Aggiorniamo a ADESSO
    this.facade.markAllSeen();
    
    // 3. Puliamo il badge
    this.facade.fetchBadgeData();
  }

  isNew(dateIso: string | undefined): boolean {
    if (!dateIso) return false;
  
    // SE sessionEntryTime è null (es. Service restituisce null al primo avvio),
    // ritorna FALSE. Questo evita l'effetto "albero di natale" (tutto verde).
    if (this.sessionEntryTime === null) return false;

    const t = new Date(dateIso).getTime();
    return t > this.sessionEntryTime;
  }

  onQuery(q: string) {
    this.facade.setQuery(q ?? '');
  }

  // --- GESTIONE FILTRI ---
  onToggleCategory(cat: NotificationCategory) {
    // 1. Aggiorna il signal locale nel facade (aggiunge/rimuove dall'array)
    this.facade.toggleCategory(cat);

    // 2. Resetta la pagina a 1
    this.notificationPaginatorService.setPage(0); // 0-based index se il tuo paginator lavora così, altrimenti 1

    // 3. Recupera la request attuale dal service
    const currentRequest =
      this.notificationPaginatorService.notificationRequest();

    // 4. Aggiorna la request con il NUOVO array di categorie dal Facade
    // (Prima era currentRequest.category = cat)
    currentRequest.categories = this.facade.selectedCategories();
    currentRequest.page = 1; // Reset pagina logica

    // 5. Fetch
    this.facade.fetchNotifications(currentRequest).subscribe();
  }

  isActive(cat: NotificationCategory): boolean {
    return this.facade.isCategorySelected(cat);
  }

  onClearFilters() {
    this.facade.clearFilters();
    this.notificationPaginatorService.setPage(0);

    const req = this.notificationPaginatorService.notificationRequest();
    req.page = 1;
    req.categories = []; // Array vuoto = Tutte

    this.facade.fetchNotifications(req).subscribe();
  }

  // --- UI HELPERS ---
  labelOf(cat: NotificationCategory | string | undefined): string {
    if (!cat) return 'Generale';
    switch (cat) {
      case 'NEW_PROPERTIES':
        return 'Nuovi immobili';
      case 'PROMOTIONAL':
        return 'Promozioni';
      case 'VISIT':
        return 'Visite';
      case 'OFFER':
        return 'Offerte';
      default:
        return 'Generale';
    }
  }

  hintOf(cat: NotificationCategory | string | undefined): string {
    if (!cat) return '';
    switch (cat) {
      case 'OFFER':
        return 'Controlla i dettagli dell’offerta.';
      case 'VISIT':
        return 'Verifica data/ora.';
      case 'NEW_PROPERTIES':
        return 'Nuovi annunci per te.';
      case 'PROMOTIONAL':
        return 'Comunicazioni.';
      default:
        return '';
    }
  }

  relativeTime(iso: string | undefined): string {
    if (!iso) return '';
    const t = new Date(iso).getTime();
    const diff = Date.now() - t;
    const m = Math.floor(diff / 60000);
    if (m < 1) return 'adesso';
    if (m < 60) return `${m} min fa`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h} h fa`;
    const d = Math.floor(h / 24);
    return `${d} g fa`;
  }
}
