import { Component, OnDestroy, computed, effect, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { CreateAdFacade } from './create-ad.facade';
import { ToastrService } from 'ngx-toastr';
import { DiscardDialogComponent } from '../dialog/discard-dialog/discard-dialog.component';
import { Category } from '../../interfaces/category';

@Component({
  selector: 'app-step-basics',
  standalone: true,
  imports: [ReactiveFormsModule, DiscardDialogComponent],
  templateUrl: './step-basics.component.html',
})
export class StepBasicsComponent implements OnDestroy {
  private activatedRoute = inject(ActivatedRoute);
  private toastrService = inject(ToastrService);
  private formBuilder = inject(FormBuilder);
  private facade = inject(CreateAdFacade);
  private routerService = inject(Router);

  private savedBasics = computed(() => this.facade.getBasics());

  isDiscardModalOpen = false;
  private skipAutosave = false;

  form = this.formBuilder.nonNullable.group({
    category: ['SALE' as Category, Validators.required],
    description: ['', [Validators.required, Validators.minLength(3)]],
  });

  constructor() {
    effect(() => {
      const saved = this.savedBasics();
      if (!saved) return;

      this.form.patchValue(
        {
          category: saved.category,
          description: saved.description ?? '',
        },
        { emitEvent: false },
      );
    });
  }

  openDiscardModal() {
    this.isDiscardModalOpen = true;
  }

  closeDiscardModal() {
    this.isDiscardModalOpen = false;
  }

  confirmDiscard() {
    this.closeDiscardModal();
    this.skipAutosave = true;
    this.facade.clearSavedData();
    this.routerService.navigate(['/']);
    this.toastrService.error('Creazione annuncio interrotta!', 'Cancellazione');
  }

  next() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.facade.setBasics(this.form.getRawValue());

    this.routerService.navigate(['../details'], {
      relativeTo: this.activatedRoute,
    });
  }

  ngOnDestroy() {
    if (this.skipAutosave) return;
    this.facade.setBasics(this.form.getRawValue());
  }
}
