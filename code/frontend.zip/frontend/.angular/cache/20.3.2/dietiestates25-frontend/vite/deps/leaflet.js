import {
  require_leaflet_src
} from "./chunk-JDGKVMG6.js";
import "./chunk-3OV72XIM.js";
export default require_leaflet_src();
